package com.retrohub.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection

private data class Platform(
    val name: String,
    val arabic: String,
    val icon: String,
    val accent: Color,
    val games: Int
)

private val platforms = listOf(
    Platform("PlayStation 2", "بلايستيشن 2", "🎮", Color(0xFF4267D5), 0),
    Platform("PlayStation 1", "بلايستيشن 1", "🕹️", Color(0xFF7A65D8), 0),
    Platform("PSP", "بلايستيشن محمول", "🎯", Color(0xFF397DBB), 0),
    Platform("Nintendo 64", "نينتندو 64", "🟣", Color(0xFF8D55C7), 0),
    Platform("SNES", "سوبر نينتندو", "🟠", Color(0xFFB66B42), 0),
    Platform("NES", "نينتندو القديمة", "🔴", Color(0xFFB94B55), 0),
    Platform("Game Boy", "جيم بوي", "🟢", Color(0xFF57966A), 0),
    Platform("GBA", "جيم بوي أدفانس", "🟩", Color(0xFF4C9C8A), 0),
    Platform("Nintendo DS", "نينتندو DS", "📟", Color(0xFF4B82A8), 0),
    Platform("Sega", "سيغا", "💠", Color(0xFF397EAA), 0),
    Platform("Dreamcast", "دريم كاست", "🌐", Color(0xFF548BBD), 0),
    Platform("Arcade", "ألعاب الصالات", "👾", Color(0xFFB45C91), 0)
)

private val bg = Color(0xFF080B14)
private val panel = Color(0xFF121827)
private val muted = Color(0xFF9AA7BD)
private val cyan = Color(0xFF54D7F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RetroHubApp() }
    }
}

@Composable
fun RetroHubApp() {
    var selected by remember { mutableIntStateOf(0) }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = darkColorScheme(
            primary = cyan,
            background = bg,
            surface = panel,
            onBackground = Color.White,
            onSurface = Color.White
        )) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xFF111B30), bg)))
                    .padding(horizontal = 28.dp, vertical = 18.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("RETRO HUB", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                            Text("مكتبتك للألعاب الكلاسيكية", color = muted, fontSize = 13.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = RoundedCornerShape(50), color = Color(0xFF1A2B40)) {
                                Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Gamepad, null, tint = cyan, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(7.dp))
                                    Text("مركز الألعاب", color = Color.White, fontSize = 13.sp)
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Icon(Icons.Default.Settings, contentDescription = "الإعدادات", tint = muted)
                        }
                    }

                    Spacer(Modifier.height(22.dp))
                    Text("منصاتك", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("اختر المنصة لعرض مكتبتها", color = muted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))

                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        items(platforms) { platform ->
                            val index = platforms.indexOf(platform)
                            PlatformCard(platform, selected == index) { selected = index }
                        }
                    }

                    Spacer(Modifier.height(18.dp))
                    val current = platforms[selected]
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = panel.copy(alpha = 0.92f),
                        shape = RoundedCornerShape(22.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.07f))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize().padding(22.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(current.name, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                Text(current.arabic, color = cyan, fontSize = 14.sp)
                                Spacer(Modifier.height(15.dp))
                                Text("مكتبة الألعاب", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                Text("لا توجد ألعاب مضافة حالياً", color = muted, fontSize = 13.sp)
                                Spacer(Modifier.height(7.dp))
                                Text("عدد الألعاب: ${current.games}", color = muted, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier.size(118.dp).background(
                                        Brush.linearGradient(listOf(current.accent.copy(alpha = .65f), Color(0xFF1B2940))),
                                        RoundedCornerShape(25.dp)
                                    ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(current.icon, fontSize = 54.sp)
                                }
                                Spacer(Modifier.height(10.dp))
                                FilledTonalButton(onClick = { }, enabled = false) {
                                    Icon(Icons.Default.Add, null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("إضافة ألعاب قريباً")
                                }
                            }
                        }
                    }
                }
                Text(
                    "RETRO HUB  •  الإصدار التجريبي 1.0",
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 3.dp, bottom = 1.dp),
                    color = Color(0xFF65728A),
                    fontSize = 9.sp
                )
            }
        }
    }
}

@Composable
private fun PlatformCard(platform: Platform, selected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(142.dp)
            .height(116.dp)
            .background(
                if (selected) Color(0xFF243650) else Color(0xFF141D2D),
                RoundedCornerShape(16.dp)
            )
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) cyan else Color.White.copy(alpha = .06f),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(platform.icon, fontSize = 25.sp)
            Spacer(Modifier.width(8.dp))
            Text(platform.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 2)
        }
        Column {
            Text(platform.arabic, color = muted, fontSize = 10.sp)
            Text("${platform.games} لعبة", color = if (selected) cyan else Color(0xFFB7C2D3), fontSize = 10.sp)
        }
    }
}
